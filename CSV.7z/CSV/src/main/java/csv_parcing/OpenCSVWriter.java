package csv_parcing;

import com.opencsv.CSVWriter;

import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

public class OpenCSVWriter {
    private static final String STRING_ARRAY_SAMPLE = "./string-array-sample.csv";

    public static void main(String[] args) throws IOException {
        try (
                Writer writer = Files.newBufferedWriter(Paths.get(STRING_ARRAY_SAMPLE));

                CSVWriter csvWriter = new CSVWriter(writer,
                        CSVWriter.DEFAULT_SEPARATOR,
                        CSVWriter.NO_QUOTE_CHARACTER,
                        CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                        CSVWriter.DEFAULT_LINE_END);
        ) {
            String[] headerRecord = {"Name", "E-mail", "Phone", "Faculty"};
            csvWriter.writeNext(headerRecord);

            csvWriter.writeNext(new String[]{"Alex Ivanov", "alex.ivanov@gmail.com", "069878787", "Applied Informatics"});
            csvWriter.writeNext(new String[]{"Mixa Lab", "misha.klass@outlook.com", "079654321", "Science of computer"});
        }
    }
}